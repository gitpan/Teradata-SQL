# Test data returning statements
use Teradata::SQL qw(:all);

$dbh = Teradata::SQL::connect("demotdat/sysdba,sysdba");
$rh = $dbh->open("help database sysdba");
print "nrows is $activcount\n";
while (@row = $rh->fetchrow_list) {
   print "object: @row\n";
}
$rh->close;

print "\n-------------\n";

$rh = $dbh->open("exec sysdba.get_next_num");
print "nrows is $activcount\n";
while (@row = $rh->fetchrow_list) {
   print "result: @row\n";
}
$rh->close;

$dbh->disconnect;
