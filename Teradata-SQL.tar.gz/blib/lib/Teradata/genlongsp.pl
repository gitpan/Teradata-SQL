# perl
# Generate text for a long stored procedure.
for ($i=0; $i<900; $i++) {
   $str = '';
   for ($j=0; $j< 50; $j++) {
      $str .= substr('AbcDefGhiJklMnoPqrStuVwxYz012356789^()~', int(rand(40)),1);
   }
   print "insert sysdba.longsptest($i, '$str');\n";
}
